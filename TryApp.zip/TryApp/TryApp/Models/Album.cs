﻿namespace TryApp.Models
{
    public class Album
    {
        private MusicStoreContext trial;

        public int Id { get; set; }

        public string Name { get; set; }

        public string Item { get; set; }



    }
}